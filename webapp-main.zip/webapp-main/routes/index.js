const healthRoutes = require('./healthRoutes');
const assignmentRoutes = require('./assignmentRoutes');

module.exports = {
    healthRoutes,
    assignmentRoutes
};
